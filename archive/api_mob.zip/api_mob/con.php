<?php
include("db_connect.php");

$response=array();

if(isset($_GET["email"])){
    
    $email = $_GET["email"];
    $req = mysqli_query($cnx,"SELECT * FROM user WHERE email='$email' ");
    $info = mysqli_fetch_assoc($req);
    $id = $info["id"];
    if($info["niveau"] == 1){
        
        $response["success"] = 1;
        $response["id"] = $id;
        echo json_encode($response);
        
    }else{
        if($info["niveau"] == 2){
            
            $response["success"] = 2;
            $response["id"] = $id;
            echo json_encode($response);
            
        }
        
    }
    
    
}


?>